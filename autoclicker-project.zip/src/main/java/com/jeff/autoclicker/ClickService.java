package com.jeff.autoclicker;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.TextView;

public class ClickService extends AccessibilityService {

    /** Time between taps. 200 ms = 5 taps per second. */
    private static final long INTERVAL_MS = 200;
    /** How long each tap is held down. */
    private static final long TAP_DURATION_MS = 10;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private WindowManager wm;
    private View target;
    private TextView button;
    private WindowManager.LayoutParams targetLp;
    private WindowManager.LayoutParams buttonLp;
    private int targetSize;
    private boolean running = false;

    private final Runnable tapLoop = new Runnable() {
        @Override
        public void run() {
            if (!running) return;
            tap();
            handler.postDelayed(this, INTERVAL_MS);
        }
    };

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        float d = getResources().getDisplayMetrics().density;

        // Red target circle: drag it onto the spot to tap.
        targetSize = (int) (56 * d);
        target = new View(this);
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(0x55FF3B30);
        circle.setStroke((int) (3 * d), 0xFFFF3B30);
        target.setBackground(circle);
        targetLp = overlayParams(targetSize, targetSize);
        targetLp.x = (int) (150 * d);
        targetLp.y = (int) (350 * d);

        // Start/stop button.
        int btnSize = (int) (52 * d);
        button = new TextView(this);
        button.setText("▶");
        button.setTextSize(22);
        button.setTextColor(Color.WHITE);
        button.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(0xDD202124);
        button.setBackground(bg);
        buttonLp = overlayParams(btnSize, btnSize);
        buttonLp.x = (int) (16 * d);
        buttonLp.y = (int) (160 * d);

        makeDraggable(target, targetLp, null);
        makeDraggable(button, buttonLp, this::toggle);

        wm.addView(target, targetLp);
        wm.addView(button, buttonLp);
    }

    private WindowManager.LayoutParams overlayParams(int w, int h) {
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                w, h,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        return lp;
    }

    private void makeDraggable(View view, WindowManager.LayoutParams lp, Runnable onClick) {
        final int slop = ViewConfiguration.get(this).getScaledTouchSlop();
        view.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY;
            int startX, startY;
            boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = e.getRawX();
                        downY = e.getRawY();
                        startX = lp.x;
                        startY = lp.y;
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - downX;
                        float dy = e.getRawY() - downY;
                        if (Math.abs(dx) > slop || Math.abs(dy) > slop) moved = true;
                        if (moved) {
                            lp.x = startX + (int) dx;
                            lp.y = startY + (int) dy;
                            wm.updateViewLayout(v, lp);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved && onClick != null) onClick.run();
                        return true;
                }
                return false;
            }
        });
    }

    private void toggle() {
        running = !running;
        if (running) {
            // Let our own taps pass through the target to the game underneath.
            targetLp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
            wm.updateViewLayout(target, targetLp);
            button.setText("■");
            handler.post(tapLoop);
        } else {
            stopTapping();
        }
    }

    private void stopTapping() {
        running = false;
        handler.removeCallbacks(tapLoop);
        if (target != null && target.isAttachedToWindow()) {
            targetLp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
            wm.updateViewLayout(target, targetLp);
        }
        if (button != null) button.setText("▶");
    }

    private void tap() {
        int[] loc = new int[2];
        target.getLocationOnScreen(loc);
        float x = loc[0] + targetSize / 2f;
        float y = loc[1] + targetSize / 2f;

        Path path = new Path();
        path.moveTo(x, y);
        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0, TAP_DURATION_MS))
                .build();
        dispatchGesture(gesture, null, null);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) { }

    @Override
    public void onInterrupt() {
        stopTapping();
    }

    @Override
    public void onDestroy() {
        running = false;
        handler.removeCallbacks(tapLoop);
        try { if (target != null) wm.removeView(target); } catch (Exception ignored) { }
        try { if (button != null) wm.removeView(button); } catch (Exception ignored) { }
        super.onDestroy();
    }
}
