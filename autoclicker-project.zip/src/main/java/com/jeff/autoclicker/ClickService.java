package com.jeff.autoclicker;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

public class ClickService extends AccessibilityService {

    /*
     * Android's gesture API works in whole milliseconds, and each tap needs
     * at least 1 ms pressed + 1 ms released, so 500 taps/s is the hard ceiling.
     */
    private static final int MIN_RATE = 1;       // taps per second
    private static final int MAX_RATE = 500;
    private static final int DEFAULT_RATE = 5;
    private static final int SLIDER_STEPS = 1000;
    /** Each gesture batch packs up to this many taps (Android allows 10 strokes). */
    private static final int MAX_TAPS_PER_BATCH = 10;
    /** Keep a batch short so Stop and speed changes react quickly. */
    private static final long MAX_BATCH_MS = 100;
    /** If the user touches the screen, pause injection briefly so they can press the bar. */
    private static final long BACKOFF_MS = 300;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private WindowManager wm;
    private SharedPreferences prefs;

    private View target;
    private LinearLayout panel;
    private TextView playButton;
    private TextView rateLabel;
    private WindowManager.LayoutParams targetLp;
    private WindowManager.LayoutParams panelLp;
    private int targetSize;

    private volatile int rate = DEFAULT_RATE;
    private boolean running = false;
    private int session = 0;            // invalidates callbacks from a previous run
    private long nextBatchAt;           // uptime (ms) when the next batch is due

    private final Runnable batchRunnable = this::dispatchBatch;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        prefs = getSharedPreferences("settings", MODE_PRIVATE);
        rate = clamp(prefs.getInt("rate", DEFAULT_RATE));
        float d = getResources().getDisplayMetrics().density;

        // ---- Red target circle: drag it onto the spot to tap ----
        targetSize = (int) (56 * d);
        target = new View(this);
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(0x55FF3B30);
        circle.setStroke((int) (3 * d), 0xFFFF3B30);
        target.setBackground(circle);
        targetLp = overlayParams(targetSize, targetSize);
        targetLp.x = (int) (150 * d);
        targetLp.y = (int) (350 * d);
        makeDraggable(target, target, targetLp);

        // ---- Control bar: [drag] [play] [speed slider] [rate] [exit] ----
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.HORIZONTAL);
        panel.setGravity(Gravity.CENTER_VERTICAL);
        int pad = (int) (6 * d);
        panel.setPadding(pad, pad, pad, pad);
        GradientDrawable panelBg = new GradientDrawable();
        panelBg.setCornerRadius(28 * d);
        panelBg.setColor(0xE6202124);
        panel.setBackground(panelBg);

        int btn = (int) (44 * d);

        TextView handle = label("⠿", 22, btn, btn);
        handle.setTextColor(0xFFAAAAAA);

        playButton = label("▶", 22, btn, btn);

        SeekBar slider = new SeekBar(this);
        slider.setMax(SLIDER_STEPS);
        slider.setProgress(rateToProgress(rate));
        slider.setLayoutParams(new LinearLayout.LayoutParams((int) (150 * d),
                ViewGroup.LayoutParams.WRAP_CONTENT));
        slider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int progress, boolean fromUser) {
                if (!fromUser) return;
                rate = progressToRate(progress);
                rateLabel.setText(rate + "/s");
                prefs.edit().putInt("rate", rate).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });

        rateLabel = label(rate + "/s", 14, (int) (58 * d), btn);

        TextView exit = label("✕", 20, btn, btn);
        exit.setTextColor(0xFFFF6B6B);
        exit.setOnClickListener(v -> exitApp());

        panel.addView(handle);
        panel.addView(playButton);
        panel.addView(slider);
        panel.addView(rateLabel);
        panel.addView(exit);

        panelLp = overlayParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        panelLp.x = (int) (8 * d);
        panelLp.y = (int) (120 * d);

        makeDraggable(handle, panel, panelLp);
        playButton.setOnClickListener(v -> toggle());

        wm.addView(target, targetLp);
        wm.addView(panel, panelLp);
    }

    // ---------- speed slider: logarithmic so 1–20/s stays easy to pick ----------

    private static int progressToRate(int progress) {
        double f = progress / (double) SLIDER_STEPS;
        return clamp((int) Math.round(Math.exp(f * Math.log(MAX_RATE / (double) MIN_RATE)) * MIN_RATE));
    }

    private static int rateToProgress(int r) {
        return (int) Math.round(Math.log(r / (double) MIN_RATE)
                / Math.log(MAX_RATE / (double) MIN_RATE) * SLIDER_STEPS);
    }

    private static int clamp(int r) {
        return Math.max(MIN_RATE, Math.min(MAX_RATE, r));
    }

    // ---------- overlay helpers ----------

    private TextView label(String text, int sp, int w, int h) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(Color.WHITE);
        t.setGravity(Gravity.CENTER);
        t.setLayoutParams(new LinearLayout.LayoutParams(w, h));
        return t;
    }

    private WindowManager.LayoutParams overlayParams(int w, int h) {
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                w, h,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        return lp;
    }

    /** Dragging {@code grip} moves the overlay window {@code window}. */
    private void makeDraggable(View grip, View window, WindowManager.LayoutParams lp) {
        final int slop = ViewConfiguration.get(this).getScaledTouchSlop();
        grip.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY;
            int startX, startY;
            boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = e.getRawX();
                        downY = e.getRawY();
                        startX = lp.x;
                        startY = lp.y;
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - downX;
                        float dy = e.getRawY() - downY;
                        if (Math.abs(dx) > slop || Math.abs(dy) > slop) moved = true;
                        if (moved) {
                            lp.x = startX + (int) dx;
                            lp.y = startY + (int) dy;
                            wm.updateViewLayout(window, lp);
                        }
                        return true;
                }
                return true;
            }
        });
    }

    // ---------- start / stop / exit ----------

    private void toggle() {
        if (running) {
            stopTapping();
            return;
        }
        running = true;
        session++;
        // Let our own taps pass through the target to the game underneath.
        targetLp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        wm.updateViewLayout(target, targetLp);
        playButton.setText("■");
        nextBatchAt = SystemClock.uptimeMillis();
        handler.post(batchRunnable);
    }

    private void stopTapping() {
        running = false;
        session++;
        handler.removeCallbacks(batchRunnable);
        if (target != null && target.isAttachedToWindow()) {
            targetLp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
            wm.updateViewLayout(target, targetLp);
        }
        if (playButton != null) playButton.setText("▶");
    }

    private void exitApp() {
        stopTapping();
        removeOverlay();
        disableSelf();
    }

    private void removeOverlay() {
        try { if (target != null && target.isAttachedToWindow()) wm.removeView(target); }
        catch (Exception ignored) { }
        try { if (panel != null && panel.isAttachedToWindow()) wm.removeView(panel); }
        catch (Exception ignored) { }
    }

    // ---------- tapping ----------

    /**
     * Sends a short burst of taps as one gesture (up to 10 taps, ≤100 ms),
     * then schedules the next burst when this one finishes. Chaining on the
     * completion callback avoids one burst cancelling the previous one.
     */
    private void dispatchBatch() {
        if (!running) return;
        final int mySession = session;

        double interval = 1000.0 / rate;                       // ms between taps
        long press = Math.max(1, (long) Math.floor(interval / 2));
        int taps = (int) Math.max(1, Math.min(MAX_TAPS_PER_BATCH,
                Math.floor(MAX_BATCH_MS / interval)));

        int[] loc = new int[2];
        target.getLocationOnScreen(loc);
        float x = loc[0] + targetSize / 2f;
        float y = loc[1] + targetSize / 2f;

        GestureDescription.Builder builder = new GestureDescription.Builder();
        for (int i = 0; i < taps; i++) {
            Path path = new Path();
            path.moveTo(x, y);
            long start = Math.round(i * interval);
            builder.addStroke(new GestureDescription.StrokeDescription(path, start, press));
        }

        nextBatchAt += Math.round(taps * interval);

        boolean sent = dispatchGesture(builder.build(), new GestureResultCallback() {
            @Override
            public void onCompleted(GestureDescription g) {
                if (mySession != session || !running) return;
                long now = SystemClock.uptimeMillis();
                if (nextBatchAt < now - 50) nextBatchAt = now;  // don't try to "catch up"
                handler.postAtTime(batchRunnable, Math.max(now, nextBatchAt));
            }

            @Override
            public void onCancelled(GestureDescription g) {
                // Usually means a finger touched the screen: back off so the
                // user can reach the ■ / ✕ buttons.
                if (mySession != session || !running) return;
                nextBatchAt = SystemClock.uptimeMillis() + BACKOFF_MS;
                handler.postAtTime(batchRunnable, nextBatchAt);
            }
        }, handler);

        if (!sent) {
            nextBatchAt = SystemClock.uptimeMillis() + BACKOFF_MS;
            handler.postAtTime(batchRunnable, nextBatchAt);
        }
    }

    /** Volume Down stops tapping instantly — a safety switch at high speeds. */
    @Override
    protected boolean onKeyEvent(KeyEvent event) {
        if (running && event.getKeyCode() == KeyEvent.KEYCODE_VOLUME_DOWN) {
            if (event.getAction() == KeyEvent.ACTION_DOWN) handler.post(this::stopTapping);
            return true;
        }
        return false;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) { }

    @Override
    public void onInterrupt() {
        stopTapping();
    }

    @Override
    public void onDestroy() {
        running = false;
        session++;
        handler.removeCallbacks(batchRunnable);
        removeOverlay();
        super.onDestroy();
    }
}
