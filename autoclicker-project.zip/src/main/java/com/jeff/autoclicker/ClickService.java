package com.jeff.autoclicker;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

public class ClickService extends AccessibilityService {

    private static final int MIN_RATE = 1;      // taps per second
    private static final int MAX_RATE = 20;
    private static final int DEFAULT_RATE = 5;
    private static final long TAP_DURATION_MS = 10;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private WindowManager wm;
    private SharedPreferences prefs;

    private View target;
    private LinearLayout panel;
    private TextView playButton;
    private TextView rateLabel;
    private WindowManager.LayoutParams targetLp;
    private WindowManager.LayoutParams panelLp;
    private int targetSize;

    private int rate = DEFAULT_RATE;
    private boolean running = false;

    private final Runnable tapLoop = new Runnable() {
        @Override
        public void run() {
            if (!running) return;
            tap();
            handler.postDelayed(this, 1000L / rate);
        }
    };

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        prefs = getSharedPreferences("settings", MODE_PRIVATE);
        rate = clamp(prefs.getInt("rate", DEFAULT_RATE));
        float d = getResources().getDisplayMetrics().density;

        // ---- Red target circle: drag it onto the spot to tap ----
        targetSize = (int) (56 * d);
        target = new View(this);
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(0x55FF3B30);
        circle.setStroke((int) (3 * d), 0xFFFF3B30);
        target.setBackground(circle);
        targetLp = overlayParams(targetSize, targetSize);
        targetLp.x = (int) (150 * d);
        targetLp.y = (int) (350 * d);
        makeDraggable(target, target, targetLp, null);

        // ---- Control bar: [drag] [play] [speed slider] [rate] [exit] ----
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.HORIZONTAL);
        panel.setGravity(Gravity.CENTER_VERTICAL);
        int pad = (int) (6 * d);
        panel.setPadding(pad, pad, pad, pad);
        GradientDrawable panelBg = new GradientDrawable();
        panelBg.setCornerRadius(28 * d);
        panelBg.setColor(0xE6202124);
        panel.setBackground(panelBg);

        int btn = (int) (44 * d);

        TextView handle = label("⠿", 22, btn, btn);
        handle.setTextColor(0xFFAAAAAA);

        playButton = label("▶", 22, btn, btn);

        SeekBar slider = new SeekBar(this);
        slider.setMax(MAX_RATE - MIN_RATE);
        slider.setProgress(rate - MIN_RATE);
        slider.setLayoutParams(new LinearLayout.LayoutParams((int) (140 * d),
                ViewGroup.LayoutParams.WRAP_CONTENT));
        slider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int progress, boolean fromUser) {
                rate = clamp(progress + MIN_RATE);
                rateLabel.setText(rate + "/s");
                prefs.edit().putInt("rate", rate).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });

        rateLabel = label(rate + "/s", 15, (int) (46 * d), btn);

        TextView exit = label("✕", 20, btn, btn);
        exit.setTextColor(0xFFFF6B6B);
        exit.setOnClickListener(v -> exitApp());

        panel.addView(handle);
        panel.addView(playButton);
        panel.addView(slider);
        panel.addView(rateLabel);
        panel.addView(exit);

        panelLp = overlayParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        panelLp.x = (int) (8 * d);
        panelLp.y = (int) (120 * d);

        // Drag the bar by its handle; tap ▶ to start/stop.
        makeDraggable(handle, panel, panelLp, null);
        playButton.setOnClickListener(v -> toggle());

        wm.addView(target, targetLp);
        wm.addView(panel, panelLp);
    }

    private TextView label(String text, int sp, int w, int h) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(Color.WHITE);
        t.setGravity(Gravity.CENTER);
        t.setLayoutParams(new LinearLayout.LayoutParams(w, h));
        return t;
    }

    private static int clamp(int r) {
        return Math.max(MIN_RATE, Math.min(MAX_RATE, r));
    }

    private WindowManager.LayoutParams overlayParams(int w, int h) {
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                w, h,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        return lp;
    }

    /** Dragging {@code grip} moves the overlay window {@code window}. */
    private void makeDraggable(View grip, View window, WindowManager.LayoutParams lp,
                               Runnable onClick) {
        final int slop = ViewConfiguration.get(this).getScaledTouchSlop();
        grip.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY;
            int startX, startY;
            boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = e.getRawX();
                        downY = e.getRawY();
                        startX = lp.x;
                        startY = lp.y;
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - downX;
                        float dy = e.getRawY() - downY;
                        if (Math.abs(dx) > slop || Math.abs(dy) > slop) moved = true;
                        if (moved) {
                            lp.x = startX + (int) dx;
                            lp.y = startY + (int) dy;
                            wm.updateViewLayout(window, lp);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved && onClick != null) onClick.run();
                        return true;
                }
                return false;
            }
        });
    }

    private void toggle() {
        if (running) {
            stopTapping();
            return;
        }
        running = true;
        // Let our own taps pass through the target to the game underneath.
        targetLp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        wm.updateViewLayout(target, targetLp);
        playButton.setText("■");
        handler.post(tapLoop);
    }

    private void stopTapping() {
        running = false;
        handler.removeCallbacks(tapLoop);
        if (target != null && target.isAttachedToWindow()) {
            targetLp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
            wm.updateViewLayout(target, targetLp);
        }
        if (playButton != null) playButton.setText("▶");
    }

    /** Stops tapping, removes the overlay and switches the service off. */
    private void exitApp() {
        stopTapping();
        removeOverlay();
        disableSelf();
    }

    private void removeOverlay() {
        try { if (target != null && target.isAttachedToWindow()) wm.removeView(target); }
        catch (Exception ignored) { }
        try { if (panel != null && panel.isAttachedToWindow()) wm.removeView(panel); }
        catch (Exception ignored) { }
    }

    private void tap() {
        int[] loc = new int[2];
        target.getLocationOnScreen(loc);
        float x = loc[0] + targetSize / 2f;
        float y = loc[1] + targetSize / 2f;

        Path path = new Path();
        path.moveTo(x, y);
        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0, TAP_DURATION_MS))
                .build();
        dispatchGesture(gesture, null, null);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) { }

    @Override
    public void onInterrupt() {
        stopTapping();
    }

    @Override
    public void onDestroy() {
        running = false;
        handler.removeCallbacks(tapLoop);
        removeOverlay();
        super.onDestroy();
    }
}
