package com.jeff.autoclicker;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        int pad = (int) (24 * getResources().getDisplayMetrics().density);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(pad, pad * 2, pad, pad);

        TextView info = new TextView(this);
        info.setTextSize(17);
        info.setText(
                "1. Tap the button below and turn on \"Auto Clicker\".\n\n"
              + "2. A red circle (the target) and a control bar appear on screen.\n\n"
              + "3. Open your game, drag the red circle onto the spot to tap.\n\n"
              + "4. Tap ▶ to start, ■ to stop. Slide to set speed (1–20 taps/sec).\n"
              + "   Drag the bar by ⠿.\n\n"
              + "5. Tap ✕ to close everything. Come back here to turn it on again.");

        Button open = new Button(this);
        open.setText("Open Accessibility settings");
        open.setOnClickListener(v ->
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));

        layout.addView(info);
        layout.addView(open);
        setContentView(layout);
    }
}
